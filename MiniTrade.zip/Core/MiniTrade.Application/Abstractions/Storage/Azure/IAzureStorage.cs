using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiniTrade.Application.Abstractions.Storage.Azure
{
  public interface IAzureStorage : IStorage
  {
  }
}
