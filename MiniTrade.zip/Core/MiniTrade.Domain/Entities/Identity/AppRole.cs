using Microsoft.AspNetCore.Identity;


namespace MiniTrade.Domain.Entities.Identity
{
  public  class AppRole:IdentityRole<string>
  {
  }
}
