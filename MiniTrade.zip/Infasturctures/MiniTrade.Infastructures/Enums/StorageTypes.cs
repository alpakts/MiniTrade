using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiniTrade.Infastructures.Enums
{
  public enum StorageTypes
  {
    AWS,
    Azure,
    Local
  }
}
