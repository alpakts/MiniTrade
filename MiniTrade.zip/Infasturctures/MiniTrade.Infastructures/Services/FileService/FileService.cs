using MiniTrade.Infastructures.StaticServices;
//todo dosya yükleme işlemi bitirilecek
namespace MiniTrade.Infastructures.Services.FileService
{

  public class FileService
  {
 
    
  }
}
